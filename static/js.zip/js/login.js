function login(event) {
    event.preventDefault();
  
    const usernameInput = $('#username');
    const passwordInput = $('#password');
  
    const username = usernameInput.val();
    const password = passwordInput.val();
  
    if (username && password) {
      const formData = new FormData();
      formData.append('username', username);
      formData.append('password', password);
  
      $.ajax({
        url: '/auth/login',
        method: 'POST',
        data: formData,
        processData: false,
        contentType: false,
        success: function (data) {
          if (data.status === 'success') {
            alert(`Logged in as ${data.user.username} (${data.user.role})`);
            window.location.href = '/index.html';
          } else if (data.status === 'failed') {
            alert(data.message);
          } else {
            alert('Unknown error');
          }
        },
        error: function (xhr) {
          if (xhr.status === 401) {
            const errorMessage = xhr.responseJSON.message;
            alert(errorMessage);
          } else {
            alert('Unknown error');
          }
        },
      });
    } else {
      alert('Username and password cannot be empty');
    }
  }