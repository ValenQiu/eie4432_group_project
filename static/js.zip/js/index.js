$(document).ready(function (event) {
    $.ajax({
      url: '/auth/me',
      method: 'GET',
      success: function (data) {
        // API call successful
        const username = data.user.username;
        const role = data.user.role;
        $('#greeting').text(`Welcome, ${username} (${role})`);
      },
      error: function () {
        // API call failed
        alert('Please login');
        window.open('/login.html', '_self');
      },
    });

    $('#logout').click(function () {
        const confirmLogout = confirm('Confirm to logout?');
        if (confirmLogout) {
          $.ajax({
            url: '/auth/logout',
            method: 'POST',
            success: function () {
              window.location.href = '/login.html';
            },
            error: function () {
              alert('Logout failed');
            },
          });
        }
      });
  });